try{
$TPMCheck  = get-tpm

}
catch{
$ReturnStuff = $Computername + " :: Something did not work `r`n"
}

$ourObject = [PSCustomObject] @{ 
        ComputerName = $env:Computername
        TPMPresent = $TPMCheck.TPMPresent
        TPMEnabled = $TPMCheck.TPMEnabled
        TPMActivated = $TPMCheck.TPMActivated
        TPMOwned = $TPMCheck.TPMOwned
        }
    
Return $ourObject


