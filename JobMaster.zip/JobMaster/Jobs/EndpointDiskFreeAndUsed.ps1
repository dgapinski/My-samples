﻿CLS

$startTime = get-date
$ErrorActionPreference = "silentlycontinue"

$ProblemCount = 0
$ProblemsFound = @()

#region DiskInfo

write-host "Disk Info Check" -ForegroundColor Cyan

$DiskInfo = Get-CimInstance Win32_Logicaldisk -filter "DeviceID='C:'" 
$CSizeGB = $DiskInfo.Size/1GB -as [int]
$CFreeGB = [math]::Round($DiskInfo.Freespace/1GB,2)
$CUsedGB = $CSizeGB - $CFreeGB

$AllDiskInfo = Get-WmiObject -Class Win32_logicaldisk -Filter "DriveType = '3'" | Select-Object -Property DeviceID, DriveType, VolumeName, @{L='FreeSpaceGB';E={"{0:N2}" -f ($_.FreeSpace /1GB)}},@{L="Capacity";E={"{0:N2}" -f ($_.Size/1GB)}}
[decimal]$TotalCapacityGB = $null
[decimal]$TotalFreeGB = $null
[decimal]$TotalUsedGB = $null

Foreach ($CurrentDisk in $AllDiskInfo ){

    $TotalCapacityGB += $CurrentDisk.capacity
    $TotalFreeGB += $CurrentDisk.FreeSpaceGB
}

$TotalUsedGB = $TotalCapacityGB - $TotalFreeGB 



write-host "Done!" -ForegroundColor Green

#endregion DiskInfo


#region FinalInfo

write-host "Final Info" -ForegroundColor Cyan

$endTime = get-date
$TimeDifference = New-TimeSpan -Start $startTime -End $endTime 

if ($TimeDifference -lt '00:00:30.0000000'){$ScriptSpeedOK = "YES"}else{$ScriptSpeedOK = "NO"}

if ($ProblemCount -ne $null){
    if ($ProblemCount -gt 1){$ClientState = 'Error'}else{$ClientState = 'Warning'}
}

if ($ProblemCount -eq 0){
    $DisplayProblems='None'
    $ClientState = 'Sweet'
}

write-host "Done!" -ForegroundColor Green


#endregion FinalInfo


$ourObject = [PSCustomObject] @{ 
        ComputerName = $env:Computername
        ProblemCount  = $ProblemCount 
        ProblemsFound = $ProblemsFound
        ClientState = $ClientState 
        CDiskSizeGB = $CSizeGB 
        CDiskFreeGB = $CFreeGB
        CDiskUsedGB = $CUsedGB
        TotalCapacityGB = $TotalCapacityGB 
        TotalFreeGB = $TotalFreeGB 
        TotalUsedGB = $TotalUsedGB 

        }
    
Return $ourObject