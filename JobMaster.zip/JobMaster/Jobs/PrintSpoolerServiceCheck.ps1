﻿try{

    $ServiceQueryPre = Get-Service "spooler" -ErrorAction SilentlyContinue 
    Stop-Service -Name "spooler" -force
    Set-Service -Name "spooler" -Status stopped -StartupType disabled
    $ServiceQueryPost = Get-Service "spooler" -ErrorAction SilentlyContinue 
    
}

catch{
$ReturnStuff = $env:Computername + " :: Something did not work `r`n"
}

$ourObject = [PSCustomObject] @{ 
        ComputerName = $env:Computername
        ServiceQueryPre = $ServiceQueryPre.status 
        ServiceQueryPost = $ServiceQueryPost.status 
        }
    
Return $ourObject