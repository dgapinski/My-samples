

$Computername = $env:COMPUTERNAME 
try
{
    $lastbootuptime = Get-CimInstance -ClassName win32_operatingsystem -computername $Computername -erroraction silentlycontinue | select lastbootuptime
}
catch [DivideByZeroException]
{
    Write-Host "Divide by zero exception"
}
catch [System.Net.WebException],[System.Exception]
{
    $Uptime =  "Other exception"
}
finally
{
    Write-Host "cleaning up ..."
}

if ($lastbootuptime){$Uptime = New-TimeSpan -Start $lastbootuptime.lastbootuptime -End (get-date)}

$ourObject = [PSCustomObject] @{ 
        ComputerName = $Computername
        lastbootuptime = $lastbootuptime.lastbootuptime
        Uptime = $Uptime 
        }
    
Return $ourObject


