﻿try{

    $Printers = Get-printer * | where { ($_.Name -notlike 'RingCentral*') -and 
                                        ($_.Name -notlike 'Microsoft*') -and 
                                        ($_.Name -ne 'Fax') -and 
                                        ($_.Name -notlike 'OneNot*') -and
                                        ($_.Name -notlike 'Fox*') -and
                                        ($_.Name -notlike 'Send to OneNot*') } | select Type,Name,PortName
    
    $IPAddress = (Get-NetIPAddress | Where-Object -FilterScript { $_.ValidLifetime -Lt ([TimeSpan]::FromDays(1)) } | select IPAddress).IPAddress
}

catch{
$ReturnStuff = $env:Computername + " :: Something did not work `r`n"
}

$ourObject = [PSCustomObject] @{ 
        ComputerName = $env:Computername
        IPAddresses = $IPAddress
        LocalPrinters = $Printers
        
        }
    
Return $ourObject